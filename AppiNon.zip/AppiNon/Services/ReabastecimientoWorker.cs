﻿using AppiNon.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace AppiNon.Services
{
    public class ReabastecimientoWorker : BackgroundService
    {
        private readonly ILogger<ReabastecimientoWorker> _logger;
        private readonly IServiceProvider _services;

        public ReabastecimientoWorker(
            ILogger<ReabastecimientoWorker> logger,
            IServiceProvider services)
        {
            _logger = logger;
            _services = services;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation("Worker de Reabastecimiento iniciado.");

            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    using (var scope = _services.CreateScope())
                    {
                        var db = scope.ServiceProvider.GetRequiredService<PinonBdContext>();

                        // Solo productos con reabastecimiento automático
                        var productosBajoStock = await db.Producto
                            .Where(p => p.ReabastecimientoAutomatico) // Solo los automáticos
                            .Join(db.Inv,
                                p => p.id_producto,
                                i => i.IdProducto,
                                (p, i) => new { Producto = p, Inventario = i })
                            .Where(x => x.Inventario.StockActual < x.Inventario.StockMinimo)
                            .GroupJoin(db.Pedidos.Where(p => p.Estado == "Pendiente" || p.Estado == "Enviado"),
                                x => x.Producto.id_producto,
                                p => p.IdProducto,
                                (x, pedidos) => new { x.Producto, x.Inventario, Pedidos = pedidos })
                            .Where(x => !x.Pedidos.Any())
                            .Select(x => new { x.Producto, x.Inventario })
                            .ToListAsync();

                        _logger.LogInformation($"Productos con reabastecimiento automático necesitados: {productosBajoStock.Count}");

                        foreach (var item in productosBajoStock)
                        {
                            var proveedor = await db.Proveedores
                                .FirstOrDefaultAsync(p => p.ID_proveedor == item.Producto.ID_Provedor);

                            if (proveedor == null)
                            {
                                _logger.LogWarning($"Proveedor no encontrado para producto ID: {item.Producto.id_producto}");
                                continue;
                            }

                            int cantidad = Math.Max(1, item.Inventario.StockIdeal - item.Inventario.StockActual);

                            var nuevoPedido = new Pedido
                            {
                                IdProducto = item.Producto.id_producto,
                                Cantidad = cantidad,
                                Estado = "Pendiente",
                                IdProveedor = item.Producto.ID_Provedor,
                                FechaSolicitud = DateTime.Now,
                                EsAutomatico = true // Marcar como pedido automático
                            };

                            db.Pedidos.Add(nuevoPedido);
                            await db.SaveChangesAsync();

                            _logger.LogInformation($"Pedido automático {nuevoPedido.IdPedido} generado para {item.Producto.nombre_producto}");
                        }
                    }

                    await Task.Delay(TimeSpan.FromHours(24), stoppingToken);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error en el worker de reabastecimiento");
                    await Task.Delay(TimeSpan.FromMinutes(30), stoppingToken);
                }
            }
        }

        private async Task RegistrarBitacora(PinonBdContext db, string tipo, string entidad, int idEntidad, string descripcion)
        {
            // Aquí deberías obtener el ID del usuario del sistema (no hardcodeado)
            var bitacora = new Bitacora
            {
                Fecha = DateTime.Now,
                Tipo_de_Modificacion = tipo,
                ID_Usuario = 1, // Reemplazar con usuario real
                Entidad = entidad,
                ID_Entidad = idEntidad,
                Descripcion = descripcion
            };

            db.Bitacora.Add(bitacora);
            await db.SaveChangesAsync();
        }

    }
}